self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "5b688d3ba99ffe2738403375e1b812f7",
    "url": "/index.html"
  },
  {
    "revision": "eb641fa1a0efee482b15",
    "url": "/static/css/0.3e68da18.chunk.css"
  },
  {
    "revision": "d0683984c3d118cee743",
    "url": "/static/css/13.2e947bf2.chunk.css"
  },
  {
    "revision": "1d9fec035156a9272fdb",
    "url": "/static/css/14.efdeeeb4.chunk.css"
  },
  {
    "revision": "5dc1d2147ba6d6202ea9",
    "url": "/static/css/15.834d426e.chunk.css"
  },
  {
    "revision": "565931bf4971758aab51",
    "url": "/static/css/main.dfb41827.chunk.css"
  },
  {
    "revision": "eb641fa1a0efee482b15",
    "url": "/static/js/0.a359b08a.chunk.js"
  },
  {
    "revision": "783f14fa45b10e088e68f98251448010",
    "url": "/static/js/0.a359b08a.chunk.js.LICENSE.txt"
  },
  {
    "revision": "62bf895b0d177405155f",
    "url": "/static/js/1.b102d21d.chunk.js"
  },
  {
    "revision": "f599dea991b91adbbf31",
    "url": "/static/js/10.faf9249c.chunk.js"
  },
  {
    "revision": "d0683984c3d118cee743",
    "url": "/static/js/13.79cb18da.chunk.js"
  },
  {
    "revision": "f2fce78a0a0a19c2649c6b24e52364fd",
    "url": "/static/js/13.79cb18da.chunk.js.LICENSE.txt"
  },
  {
    "revision": "1d9fec035156a9272fdb",
    "url": "/static/js/14.a3e15fbd.chunk.js"
  },
  {
    "revision": "5dc1d2147ba6d6202ea9",
    "url": "/static/js/15.02ada251.chunk.js"
  },
  {
    "revision": "e0afca8bb60added33ab",
    "url": "/static/js/16.1e9cd269.chunk.js"
  },
  {
    "revision": "a96bf769dc35a1629c65",
    "url": "/static/js/17.ff51f7c8.chunk.js"
  },
  {
    "revision": "007aaa08b0d17993ec4e",
    "url": "/static/js/18.1e26e2dd.chunk.js"
  },
  {
    "revision": "c75122e192e7681ec8c0",
    "url": "/static/js/19.6cf17c25.chunk.js"
  },
  {
    "revision": "a95f4c2c977f35d5ee07",
    "url": "/static/js/2.e88f5cd1.chunk.js"
  },
  {
    "revision": "cfc7b3d602986dd02d67",
    "url": "/static/js/20.4b941c64.chunk.js"
  },
  {
    "revision": "41ff99bdaea29ca3022e",
    "url": "/static/js/21.b54f0419.chunk.js"
  },
  {
    "revision": "7af2b1f0cc6a43c6f905",
    "url": "/static/js/22.73b5d4ad.chunk.js"
  },
  {
    "revision": "253d5eb120c32d5ecfb7",
    "url": "/static/js/23.6d60bd79.chunk.js"
  },
  {
    "revision": "e9e290217327b1880a8d",
    "url": "/static/js/24.d176069c.chunk.js"
  },
  {
    "revision": "e789edb5ea9c31c2ca01",
    "url": "/static/js/25.323e970f.chunk.js"
  },
  {
    "revision": "901ed181edb27d94e89e",
    "url": "/static/js/26.eb5a8fae.chunk.js"
  },
  {
    "revision": "01ad7fec4e7eb9693901",
    "url": "/static/js/27.3025d2eb.chunk.js"
  },
  {
    "revision": "54ee884b22c286085b7d",
    "url": "/static/js/28.c6184b61.chunk.js"
  },
  {
    "revision": "9b4ae161b5b1c6d06f47",
    "url": "/static/js/29.3e894641.chunk.js"
  },
  {
    "revision": "0f33f234631b9b9a28e0",
    "url": "/static/js/3.dda741b2.chunk.js"
  },
  {
    "revision": "35120a079de660691924",
    "url": "/static/js/30.c0584ea8.chunk.js"
  },
  {
    "revision": "5b6ed25295ee5d97d09b",
    "url": "/static/js/31.63112ea5.chunk.js"
  },
  {
    "revision": "fe96eda7eea8f0b46a78",
    "url": "/static/js/32.7d667ecd.chunk.js"
  },
  {
    "revision": "7bb3ab9935b01bddca5e",
    "url": "/static/js/33.15389a00.chunk.js"
  },
  {
    "revision": "cc1dba27206d15b14657",
    "url": "/static/js/34.514c9eec.chunk.js"
  },
  {
    "revision": "85f637d8b68ffeba2434",
    "url": "/static/js/35.7984de91.chunk.js"
  },
  {
    "revision": "9e3d98c6b74271d3a6c5",
    "url": "/static/js/36.4bc985b1.chunk.js"
  },
  {
    "revision": "38545428e5dfdb481492",
    "url": "/static/js/37.f9b9fdbb.chunk.js"
  },
  {
    "revision": "728c3c326f3506b16069",
    "url": "/static/js/38.5eda89f7.chunk.js"
  },
  {
    "revision": "9d466e5ffcfb5124fc9e",
    "url": "/static/js/39.ce92dfba.chunk.js"
  },
  {
    "revision": "4138733f85c55da84c88",
    "url": "/static/js/4.283ba081.chunk.js"
  },
  {
    "revision": "bf8f0142f9d80635bf44",
    "url": "/static/js/40.13d62574.chunk.js"
  },
  {
    "revision": "9d2de2d4f24bdf82c281",
    "url": "/static/js/41.c9560058.chunk.js"
  },
  {
    "revision": "13aa5401892a6c456e58",
    "url": "/static/js/42.5c4218e0.chunk.js"
  },
  {
    "revision": "d8543d08b40b26d1318f",
    "url": "/static/js/43.ac73d686.chunk.js"
  },
  {
    "revision": "308fe78d0febb310403f",
    "url": "/static/js/44.5beed32a.chunk.js"
  },
  {
    "revision": "60d824944a34a54f3b90",
    "url": "/static/js/45.182eaa83.chunk.js"
  },
  {
    "revision": "343331c2184de3779f8f",
    "url": "/static/js/46.76763700.chunk.js"
  },
  {
    "revision": "160204888aad72aa3aba",
    "url": "/static/js/47.4c575d33.chunk.js"
  },
  {
    "revision": "d517e16b0c92ba2e8202",
    "url": "/static/js/48.6fdbb40d.chunk.js"
  },
  {
    "revision": "82081c65aae34f7d20f5",
    "url": "/static/js/49.381f4611.chunk.js"
  },
  {
    "revision": "0f8cf50bb94e32404424",
    "url": "/static/js/5.3999f700.chunk.js"
  },
  {
    "revision": "b78efd041e0ce4ea34bf",
    "url": "/static/js/50.952fef5c.chunk.js"
  },
  {
    "revision": "c12fa3aed21fdcefb616",
    "url": "/static/js/51.6f2f1210.chunk.js"
  },
  {
    "revision": "f3899a4ad26709804a0a",
    "url": "/static/js/52.5b3aed39.chunk.js"
  },
  {
    "revision": "62379c28a6cb4f6677b6",
    "url": "/static/js/53.aebc26ee.chunk.js"
  },
  {
    "revision": "25fd21ef6dec3a232c90",
    "url": "/static/js/54.c374c5d3.chunk.js"
  },
  {
    "revision": "ee3b5522c064f332e63d",
    "url": "/static/js/55.aca6c7c4.chunk.js"
  },
  {
    "revision": "6751bd0de3b4df5735c0",
    "url": "/static/js/56.7d1937b5.chunk.js"
  },
  {
    "revision": "54b3405fed56dd1b86fa",
    "url": "/static/js/57.157f3d36.chunk.js"
  },
  {
    "revision": "814a25ef53ee1e08604b",
    "url": "/static/js/58.ac6bbab8.chunk.js"
  },
  {
    "revision": "b54febd1b9bee1184119",
    "url": "/static/js/59.6e9064d5.chunk.js"
  },
  {
    "revision": "be0e77fe326d4e1aaae9",
    "url": "/static/js/6.9a9edac0.chunk.js"
  },
  {
    "revision": "77502b3d85bc2019a4c6",
    "url": "/static/js/60.4d0e5b80.chunk.js"
  },
  {
    "revision": "a1ce167abd757917807e",
    "url": "/static/js/61.7f0ba6a4.chunk.js"
  },
  {
    "revision": "2c37ce7eeafc656d92f5",
    "url": "/static/js/62.83ad12d8.chunk.js"
  },
  {
    "revision": "beccad2b639f52f04def",
    "url": "/static/js/63.741d856c.chunk.js"
  },
  {
    "revision": "b9efcfb2610dd39b7532",
    "url": "/static/js/64.006ef815.chunk.js"
  },
  {
    "revision": "f6083606f1e07fdbf376",
    "url": "/static/js/65.0befbde1.chunk.js"
  },
  {
    "revision": "e1d550ad7f2c6d226907",
    "url": "/static/js/66.d3ea38fa.chunk.js"
  },
  {
    "revision": "24c574a0afe62ed3f58b",
    "url": "/static/js/67.f0cfbea2.chunk.js"
  },
  {
    "revision": "1bc8fdebdf2fe4c3816f",
    "url": "/static/js/68.415e393a.chunk.js"
  },
  {
    "revision": "771f46d30104544f4a0a",
    "url": "/static/js/69.77b88109.chunk.js"
  },
  {
    "revision": "ce9f3ce60c5e0761ff8f",
    "url": "/static/js/7.7872c683.chunk.js"
  },
  {
    "revision": "2d051f0871cf4241346f",
    "url": "/static/js/70.5d82a9ce.chunk.js"
  },
  {
    "revision": "ad78e128709e3e876f44",
    "url": "/static/js/71.63e0322c.chunk.js"
  },
  {
    "revision": "e437b9896681d39aeae1",
    "url": "/static/js/72.316a2a8d.chunk.js"
  },
  {
    "revision": "59aa94c00cfd8e8f3ec1",
    "url": "/static/js/73.440811b5.chunk.js"
  },
  {
    "revision": "e4c78e0f03c5ddc8ce62",
    "url": "/static/js/74.fbcafadd.chunk.js"
  },
  {
    "revision": "789426e81635be265dab",
    "url": "/static/js/75.db570b46.chunk.js"
  },
  {
    "revision": "82e346a6a35287ac39b9",
    "url": "/static/js/76.7a2574a7.chunk.js"
  },
  {
    "revision": "753eb64e089c5d361045",
    "url": "/static/js/77.34ca13c8.chunk.js"
  },
  {
    "revision": "f1c1be66c812ec279c73",
    "url": "/static/js/78.8070d8c7.chunk.js"
  },
  {
    "revision": "c53c6b225c2f128c4215",
    "url": "/static/js/79.5ba3fdca.chunk.js"
  },
  {
    "revision": "2cb50e0a4abb20d2197f",
    "url": "/static/js/8.2cdbd9bb.chunk.js"
  },
  {
    "revision": "2a7eab9e3700f1d67e3c",
    "url": "/static/js/80.0dafae2f.chunk.js"
  },
  {
    "revision": "aadca23e382c9d642330",
    "url": "/static/js/9.ab3a601d.chunk.js"
  },
  {
    "revision": "565931bf4971758aab51",
    "url": "/static/js/main.16888781.chunk.js"
  },
  {
    "revision": "3e66c130e7a417072d2c",
    "url": "/static/js/runtime-main.9d6e3e30.js"
  },
  {
    "revision": "35c254f1bc43c56e8cfae5d817be8d5f",
    "url": "/static/media/1.35c254f1.jpg"
  },
  {
    "revision": "e3ecc43c35f3e4d97bf187e8fccd9965",
    "url": "/static/media/2.e3ecc43c.jpg"
  },
  {
    "revision": "ed038830eaa255c8c2d58ed871d54f97",
    "url": "/static/media/3.ed038830.jpg"
  },
  {
    "revision": "98c972f61e9885a0ceeaa243aacfa7d6",
    "url": "/static/media/4.98c972f6.jpg"
  },
  {
    "revision": "3c60e090c7128eb1c57e03cabe091c05",
    "url": "/static/media/404.3c60e090.png"
  },
  {
    "revision": "11911410dca2de148f30954eb2fd5eab",
    "url": "/static/media/arrow_left.11911410.svg"
  },
  {
    "revision": "8ef6a08cdc1154920165680a4edde771",
    "url": "/static/media/arrow_right.8ef6a08c.svg"
  },
  {
    "revision": "035047178ed13101f120c47e1f36b043",
    "url": "/static/media/avatar.03504717.png"
  },
  {
    "revision": "ad04b412ac89dfa2f4fb8734d387cad0",
    "url": "/static/media/faq.ad04b412.jpg"
  },
  {
    "revision": "3d2fa2e544004aef2ea641698b715af6",
    "url": "/static/media/feather.3d2fa2e5.woff"
  },
  {
    "revision": "6a750f0119ba9c8ab8a994a4796599a6",
    "url": "/static/media/feather.6a750f01.ttf"
  },
  {
    "revision": "7975b0a027366be768319ee2f9e1734e",
    "url": "/static/media/feather.7975b0a0.svg"
  },
  {
    "revision": "931c9e74d0b20947054bfe6a5b74a838",
    "url": "/static/media/feather.931c9e74.eot"
  },
  {
    "revision": "b17d26ffb93bddee5e782ca657ae7efd",
    "url": "/static/media/kasino-logo.b17d26ff.png"
  },
  {
    "revision": "e45627865b1429eb3f10a2b6c19541bd",
    "url": "/static/media/parallax-4.e4562786.jpg"
  }
]);