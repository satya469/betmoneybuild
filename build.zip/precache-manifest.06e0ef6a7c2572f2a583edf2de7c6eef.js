self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "9cb5df9d34e9258393c6d9ac0fc842f3",
    "url": "/index.html"
  },
  {
    "revision": "cb004587c0fe255f0db3",
    "url": "/static/css/0.3e68da18.chunk.css"
  },
  {
    "revision": "ede9146f3a4ffc0c63e1",
    "url": "/static/css/13.2e947bf2.chunk.css"
  },
  {
    "revision": "2f079585d48305c1f358",
    "url": "/static/css/14.0fa3ea69.chunk.css"
  },
  {
    "revision": "c3705b2a561d747f0865",
    "url": "/static/css/15.834d426e.chunk.css"
  },
  {
    "revision": "1b0cee4da4bcbda4db07",
    "url": "/static/css/main.dfb41827.chunk.css"
  },
  {
    "revision": "cb004587c0fe255f0db3",
    "url": "/static/js/0.2f39bd8c.chunk.js"
  },
  {
    "revision": "783f14fa45b10e088e68f98251448010",
    "url": "/static/js/0.2f39bd8c.chunk.js.LICENSE.txt"
  },
  {
    "revision": "5ca54ce0d396d0d49bb6",
    "url": "/static/js/1.8005fef7.chunk.js"
  },
  {
    "revision": "b9f2f09dec6832ca67dc",
    "url": "/static/js/10.4bd73f47.chunk.js"
  },
  {
    "revision": "ede9146f3a4ffc0c63e1",
    "url": "/static/js/13.168cfbc5.chunk.js"
  },
  {
    "revision": "f2fce78a0a0a19c2649c6b24e52364fd",
    "url": "/static/js/13.168cfbc5.chunk.js.LICENSE.txt"
  },
  {
    "revision": "2f079585d48305c1f358",
    "url": "/static/js/14.f8122a65.chunk.js"
  },
  {
    "revision": "c3705b2a561d747f0865",
    "url": "/static/js/15.9c464e61.chunk.js"
  },
  {
    "revision": "8a0e75d735c72724b7f0",
    "url": "/static/js/16.c61475ff.chunk.js"
  },
  {
    "revision": "e6f70d6301ddf2323ee6",
    "url": "/static/js/17.50665ec7.chunk.js"
  },
  {
    "revision": "b1f7b0e62185729300ca",
    "url": "/static/js/18.cb2d016f.chunk.js"
  },
  {
    "revision": "dc935f8f761a20443be8",
    "url": "/static/js/19.e4dff931.chunk.js"
  },
  {
    "revision": "0d6434f9c00cfc6a793f",
    "url": "/static/js/2.a6eb2cd6.chunk.js"
  },
  {
    "revision": "f9bc7a194d9d6f7bbfd5",
    "url": "/static/js/20.7a22b803.chunk.js"
  },
  {
    "revision": "d046966dab64da845c8e",
    "url": "/static/js/21.370919a1.chunk.js"
  },
  {
    "revision": "daddbfc3d0c5116f2aad",
    "url": "/static/js/22.7091f3fd.chunk.js"
  },
  {
    "revision": "e4ecb6317451355ced80",
    "url": "/static/js/23.91b6c4fc.chunk.js"
  },
  {
    "revision": "c7f7cce6e0444543898c",
    "url": "/static/js/24.ee01f2d5.chunk.js"
  },
  {
    "revision": "4ec6eb568fbdb64e6e90",
    "url": "/static/js/25.158d333e.chunk.js"
  },
  {
    "revision": "53bb7cac594c73b559be",
    "url": "/static/js/26.e7b63c41.chunk.js"
  },
  {
    "revision": "a9f3e95e9ec07d6b6101",
    "url": "/static/js/27.5e8f8df4.chunk.js"
  },
  {
    "revision": "21ce8b79123ef15c9f5c",
    "url": "/static/js/28.9cd041b4.chunk.js"
  },
  {
    "revision": "3561af74bd28cbed6744",
    "url": "/static/js/29.1ed9c61f.chunk.js"
  },
  {
    "revision": "f585230e5362eb299935",
    "url": "/static/js/3.15a1ea1f.chunk.js"
  },
  {
    "revision": "63b54bb833315529c0be",
    "url": "/static/js/30.a944ae47.chunk.js"
  },
  {
    "revision": "9a581757b9ea416dbb9b",
    "url": "/static/js/31.8722e407.chunk.js"
  },
  {
    "revision": "3ec037b523a75df84e1f",
    "url": "/static/js/32.fb3fa08d.chunk.js"
  },
  {
    "revision": "c83fb3c9f471f017b4d2",
    "url": "/static/js/33.cf4b8fd0.chunk.js"
  },
  {
    "revision": "a80eda09d26b69119bd7",
    "url": "/static/js/34.3cd49913.chunk.js"
  },
  {
    "revision": "090af2992f8fab7e4018",
    "url": "/static/js/35.02d39c88.chunk.js"
  },
  {
    "revision": "1d1bf65a6334531741e0",
    "url": "/static/js/36.5a006349.chunk.js"
  },
  {
    "revision": "18b1484d6af5e82c2c19",
    "url": "/static/js/37.f45f9c0a.chunk.js"
  },
  {
    "revision": "08069bcd9fbaa7a7002f",
    "url": "/static/js/38.b9a747b9.chunk.js"
  },
  {
    "revision": "d7af550bbb6db456cd53",
    "url": "/static/js/39.8ed0e90c.chunk.js"
  },
  {
    "revision": "9f37071e2058147760ae",
    "url": "/static/js/4.1a36da2d.chunk.js"
  },
  {
    "revision": "512fc021e9cf2c0516a1",
    "url": "/static/js/40.87981a44.chunk.js"
  },
  {
    "revision": "b8eda589b57716ddeef2",
    "url": "/static/js/41.c3b1b888.chunk.js"
  },
  {
    "revision": "bc81217e2a98ea02aea2",
    "url": "/static/js/42.44bca5b1.chunk.js"
  },
  {
    "revision": "1099638f42ef92492a22",
    "url": "/static/js/43.9ff277a2.chunk.js"
  },
  {
    "revision": "a91fa80ac52aa06d5529",
    "url": "/static/js/44.148c2677.chunk.js"
  },
  {
    "revision": "a9059d94870c300e0342",
    "url": "/static/js/45.73a4bd39.chunk.js"
  },
  {
    "revision": "df06e81d90a5e5f11ac1",
    "url": "/static/js/46.3eb13225.chunk.js"
  },
  {
    "revision": "1737fbfb8fc3aec33a64",
    "url": "/static/js/47.49c6568c.chunk.js"
  },
  {
    "revision": "83b236883fa42542b02c",
    "url": "/static/js/48.6858fc3b.chunk.js"
  },
  {
    "revision": "284f51b1b85ef6d53a1c",
    "url": "/static/js/49.7360a914.chunk.js"
  },
  {
    "revision": "35213a7715dd3fd0e857",
    "url": "/static/js/5.097e00d4.chunk.js"
  },
  {
    "revision": "c9be91b8ae9e2ce90094",
    "url": "/static/js/50.b04402e5.chunk.js"
  },
  {
    "revision": "b9b91bbee0051ccb9498",
    "url": "/static/js/51.4187385f.chunk.js"
  },
  {
    "revision": "c014e32b583e08951098",
    "url": "/static/js/52.5d8a86df.chunk.js"
  },
  {
    "revision": "311a877a6b3f631a8d49",
    "url": "/static/js/53.fc762b45.chunk.js"
  },
  {
    "revision": "4749e30ca298b0537dd7",
    "url": "/static/js/54.d65c64d2.chunk.js"
  },
  {
    "revision": "bffdf50a7a61004bfb5f",
    "url": "/static/js/55.e0564ae3.chunk.js"
  },
  {
    "revision": "25f2683d30c43a687c37",
    "url": "/static/js/56.b7f79dc6.chunk.js"
  },
  {
    "revision": "4d204f6f519b4b548480",
    "url": "/static/js/57.81573c7d.chunk.js"
  },
  {
    "revision": "f249f27452d7174dd7f9",
    "url": "/static/js/58.87ba91ce.chunk.js"
  },
  {
    "revision": "4957a982f318ffa1ea51",
    "url": "/static/js/59.06936967.chunk.js"
  },
  {
    "revision": "6b9b27a1bfec072301f1",
    "url": "/static/js/6.4744be89.chunk.js"
  },
  {
    "revision": "98c2696e66aeea05656a",
    "url": "/static/js/60.827e2b24.chunk.js"
  },
  {
    "revision": "f604be185a055f1a90d1",
    "url": "/static/js/61.8c26123b.chunk.js"
  },
  {
    "revision": "09c5244873edbd1f4805",
    "url": "/static/js/62.c023a940.chunk.js"
  },
  {
    "revision": "d0ac7987ff36b4908a6e",
    "url": "/static/js/63.a3d8eacc.chunk.js"
  },
  {
    "revision": "d8e3308b73406444a053",
    "url": "/static/js/64.d065a5ae.chunk.js"
  },
  {
    "revision": "4abdaadc31b772ac01ce",
    "url": "/static/js/65.b4d66e04.chunk.js"
  },
  {
    "revision": "10a6d9836c416763e9db",
    "url": "/static/js/66.dcd44374.chunk.js"
  },
  {
    "revision": "8b3ba55aa8165de1f248",
    "url": "/static/js/67.4b50cf0b.chunk.js"
  },
  {
    "revision": "2a9ee1efad5d91428a4d",
    "url": "/static/js/68.e63bff5b.chunk.js"
  },
  {
    "revision": "cde548853ae4a600345c",
    "url": "/static/js/69.9dcd72ac.chunk.js"
  },
  {
    "revision": "743dfca7f3176f51962f",
    "url": "/static/js/7.593a95c5.chunk.js"
  },
  {
    "revision": "f156bcff4a420f96eb12",
    "url": "/static/js/70.210d3e99.chunk.js"
  },
  {
    "revision": "4e2b513fee926f907ce2",
    "url": "/static/js/71.7a040aa1.chunk.js"
  },
  {
    "revision": "f9fe78e9e19bfeab81c4",
    "url": "/static/js/72.cda28724.chunk.js"
  },
  {
    "revision": "4ff1ccf747e2a4318cb6",
    "url": "/static/js/73.420440a8.chunk.js"
  },
  {
    "revision": "8cd874ed043f4ef082ab",
    "url": "/static/js/74.fbdde12b.chunk.js"
  },
  {
    "revision": "f6518b335acbd6563bb5",
    "url": "/static/js/75.6fc20a58.chunk.js"
  },
  {
    "revision": "484ccafba414bb14131f",
    "url": "/static/js/76.f806a2a9.chunk.js"
  },
  {
    "revision": "c076fa38dc25672dba83",
    "url": "/static/js/77.1b6e9280.chunk.js"
  },
  {
    "revision": "88e8ab614ff6b98944cc",
    "url": "/static/js/78.6997ca8b.chunk.js"
  },
  {
    "revision": "b2c22ff93831285c9238",
    "url": "/static/js/79.c70da2be.chunk.js"
  },
  {
    "revision": "ded28211d502ac224ff7",
    "url": "/static/js/8.ea499150.chunk.js"
  },
  {
    "revision": "8e29b450484a41923414",
    "url": "/static/js/9.9263a043.chunk.js"
  },
  {
    "revision": "1b0cee4da4bcbda4db07",
    "url": "/static/js/main.c5bee671.chunk.js"
  },
  {
    "revision": "44922a123de127f7e631",
    "url": "/static/js/runtime-main.db6522bb.js"
  },
  {
    "revision": "35c254f1bc43c56e8cfae5d817be8d5f",
    "url": "/static/media/1.35c254f1.jpg"
  },
  {
    "revision": "e3ecc43c35f3e4d97bf187e8fccd9965",
    "url": "/static/media/2.e3ecc43c.jpg"
  },
  {
    "revision": "ed038830eaa255c8c2d58ed871d54f97",
    "url": "/static/media/3.ed038830.jpg"
  },
  {
    "revision": "98c972f61e9885a0ceeaa243aacfa7d6",
    "url": "/static/media/4.98c972f6.jpg"
  },
  {
    "revision": "3c60e090c7128eb1c57e03cabe091c05",
    "url": "/static/media/404.3c60e090.png"
  },
  {
    "revision": "11911410dca2de148f30954eb2fd5eab",
    "url": "/static/media/arrow_left.11911410.svg"
  },
  {
    "revision": "8ef6a08cdc1154920165680a4edde771",
    "url": "/static/media/arrow_right.8ef6a08c.svg"
  },
  {
    "revision": "035047178ed13101f120c47e1f36b043",
    "url": "/static/media/avatar.03504717.png"
  },
  {
    "revision": "ad04b412ac89dfa2f4fb8734d387cad0",
    "url": "/static/media/faq.ad04b412.jpg"
  },
  {
    "revision": "3d2fa2e544004aef2ea641698b715af6",
    "url": "/static/media/feather.3d2fa2e5.woff"
  },
  {
    "revision": "6a750f0119ba9c8ab8a994a4796599a6",
    "url": "/static/media/feather.6a750f01.ttf"
  },
  {
    "revision": "7975b0a027366be768319ee2f9e1734e",
    "url": "/static/media/feather.7975b0a0.svg"
  },
  {
    "revision": "931c9e74d0b20947054bfe6a5b74a838",
    "url": "/static/media/feather.931c9e74.eot"
  },
  {
    "revision": "b17d26ffb93bddee5e782ca657ae7efd",
    "url": "/static/media/kasino-logo.b17d26ff.png"
  },
  {
    "revision": "e45627865b1429eb3f10a2b6c19541bd",
    "url": "/static/media/parallax-4.e4562786.jpg"
  }
]);