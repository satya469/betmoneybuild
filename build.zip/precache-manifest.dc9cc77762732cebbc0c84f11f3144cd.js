self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "94bb042c46c88dfdfb5c5eae70e34e40",
    "url": "/index.html"
  },
  {
    "revision": "cb004587c0fe255f0db3",
    "url": "/static/css/0.3e68da18.chunk.css"
  },
  {
    "revision": "15c600a6a5116ab92d76",
    "url": "/static/css/13.2e947bf2.chunk.css"
  },
  {
    "revision": "843ae2f3c74dba3b51e3",
    "url": "/static/css/14.0fa3ea69.chunk.css"
  },
  {
    "revision": "c3705b2a561d747f0865",
    "url": "/static/css/15.834d426e.chunk.css"
  },
  {
    "revision": "9b8970a7863f89c948c3",
    "url": "/static/css/main.dfb41827.chunk.css"
  },
  {
    "revision": "cb004587c0fe255f0db3",
    "url": "/static/js/0.2f39bd8c.chunk.js"
  },
  {
    "revision": "783f14fa45b10e088e68f98251448010",
    "url": "/static/js/0.2f39bd8c.chunk.js.LICENSE.txt"
  },
  {
    "revision": "b348357360e80ae9cc2a",
    "url": "/static/js/1.3d930e9e.chunk.js"
  },
  {
    "revision": "8609a1e3b23b4c074337",
    "url": "/static/js/10.ad9f69b2.chunk.js"
  },
  {
    "revision": "15c600a6a5116ab92d76",
    "url": "/static/js/13.03be5e2c.chunk.js"
  },
  {
    "revision": "f2fce78a0a0a19c2649c6b24e52364fd",
    "url": "/static/js/13.03be5e2c.chunk.js.LICENSE.txt"
  },
  {
    "revision": "843ae2f3c74dba3b51e3",
    "url": "/static/js/14.f7a27315.chunk.js"
  },
  {
    "revision": "c3705b2a561d747f0865",
    "url": "/static/js/15.9c464e61.chunk.js"
  },
  {
    "revision": "8a0e75d735c72724b7f0",
    "url": "/static/js/16.c61475ff.chunk.js"
  },
  {
    "revision": "7b0fd6ef51d615a4439c",
    "url": "/static/js/17.b71b5a5d.chunk.js"
  },
  {
    "revision": "b1f7b0e62185729300ca",
    "url": "/static/js/18.cb2d016f.chunk.js"
  },
  {
    "revision": "5bbaf501d9ee860bbf92",
    "url": "/static/js/19.769ca294.chunk.js"
  },
  {
    "revision": "0d6434f9c00cfc6a793f",
    "url": "/static/js/2.a6eb2cd6.chunk.js"
  },
  {
    "revision": "f9bc7a194d9d6f7bbfd5",
    "url": "/static/js/20.7a22b803.chunk.js"
  },
  {
    "revision": "507ddbb7d61fd19c0a98",
    "url": "/static/js/21.62eeeaf3.chunk.js"
  },
  {
    "revision": "2fbe3e22c5a3f82622f3",
    "url": "/static/js/22.c4fb7d94.chunk.js"
  },
  {
    "revision": "7b5d80b5c0259b52e063",
    "url": "/static/js/23.66cd0672.chunk.js"
  },
  {
    "revision": "ce73428d55b642f84e7f",
    "url": "/static/js/24.f34452ce.chunk.js"
  },
  {
    "revision": "c3225a6fbf5401943bd4",
    "url": "/static/js/25.48e9cd19.chunk.js"
  },
  {
    "revision": "f3d6a52d52ccb9cec9dc",
    "url": "/static/js/26.d89ef5a5.chunk.js"
  },
  {
    "revision": "31a0c7f7805a8fc5cdb8",
    "url": "/static/js/27.38bdd800.chunk.js"
  },
  {
    "revision": "cd91292b8d6dcecea255",
    "url": "/static/js/28.8bfc7318.chunk.js"
  },
  {
    "revision": "6630a839b5438c295de1",
    "url": "/static/js/29.d2d0527f.chunk.js"
  },
  {
    "revision": "f585230e5362eb299935",
    "url": "/static/js/3.15a1ea1f.chunk.js"
  },
  {
    "revision": "ba14c703642cc85f836b",
    "url": "/static/js/30.b05b0deb.chunk.js"
  },
  {
    "revision": "7bc21bbbc7370471d258",
    "url": "/static/js/31.e43d8739.chunk.js"
  },
  {
    "revision": "2fab51fc1352df4737c4",
    "url": "/static/js/32.080527ae.chunk.js"
  },
  {
    "revision": "c83fb3c9f471f017b4d2",
    "url": "/static/js/33.cf4b8fd0.chunk.js"
  },
  {
    "revision": "a80eda09d26b69119bd7",
    "url": "/static/js/34.3cd49913.chunk.js"
  },
  {
    "revision": "090af2992f8fab7e4018",
    "url": "/static/js/35.02d39c88.chunk.js"
  },
  {
    "revision": "1d1bf65a6334531741e0",
    "url": "/static/js/36.5a006349.chunk.js"
  },
  {
    "revision": "f297b2da3c2e319f2829",
    "url": "/static/js/37.b148d416.chunk.js"
  },
  {
    "revision": "498251f7d8b3f6625ff7",
    "url": "/static/js/38.c371f3aa.chunk.js"
  },
  {
    "revision": "52b08d0bf2e240241512",
    "url": "/static/js/39.9f8bd994.chunk.js"
  },
  {
    "revision": "9f37071e2058147760ae",
    "url": "/static/js/4.1a36da2d.chunk.js"
  },
  {
    "revision": "4852e5dbf1c92b6314f7",
    "url": "/static/js/40.557be97b.chunk.js"
  },
  {
    "revision": "2f25267f4d0290ec39ca",
    "url": "/static/js/41.43ee1052.chunk.js"
  },
  {
    "revision": "48135902d2b4737752c5",
    "url": "/static/js/42.2c6c5bcd.chunk.js"
  },
  {
    "revision": "35cc856a9fbcdf830497",
    "url": "/static/js/43.ca278ae6.chunk.js"
  },
  {
    "revision": "71dd582b1b3ee7c4c02b",
    "url": "/static/js/44.be6531b9.chunk.js"
  },
  {
    "revision": "a92c62170432fd70f73c",
    "url": "/static/js/45.a9a1d6cc.chunk.js"
  },
  {
    "revision": "1f4c6fc24faac2e6bff7",
    "url": "/static/js/46.6335729d.chunk.js"
  },
  {
    "revision": "b9ac601782a9d1ad773e",
    "url": "/static/js/47.5661438d.chunk.js"
  },
  {
    "revision": "8aa21dfa8b7777a6a25a",
    "url": "/static/js/48.2f675c3a.chunk.js"
  },
  {
    "revision": "1f1c839f4c08a333d35a",
    "url": "/static/js/49.a512b78c.chunk.js"
  },
  {
    "revision": "35431c06064c6061e77f",
    "url": "/static/js/5.313498f1.chunk.js"
  },
  {
    "revision": "c9be91b8ae9e2ce90094",
    "url": "/static/js/50.b04402e5.chunk.js"
  },
  {
    "revision": "c0e34650eb97f1374d17",
    "url": "/static/js/51.0392142b.chunk.js"
  },
  {
    "revision": "609e40f627865baf7c51",
    "url": "/static/js/52.65871567.chunk.js"
  },
  {
    "revision": "f3d10c985732f98934a0",
    "url": "/static/js/53.eeceb6a3.chunk.js"
  },
  {
    "revision": "2f655c39d6468ff0b683",
    "url": "/static/js/54.115a11e7.chunk.js"
  },
  {
    "revision": "f7b4ab6def514e963afa",
    "url": "/static/js/55.8138f7a2.chunk.js"
  },
  {
    "revision": "25f2683d30c43a687c37",
    "url": "/static/js/56.b7f79dc6.chunk.js"
  },
  {
    "revision": "26ef67a68496265e79c7",
    "url": "/static/js/57.4e7a292f.chunk.js"
  },
  {
    "revision": "61552586fcba5bf3986b",
    "url": "/static/js/58.94ab18f3.chunk.js"
  },
  {
    "revision": "4957a982f318ffa1ea51",
    "url": "/static/js/59.06936967.chunk.js"
  },
  {
    "revision": "6e782d456e92ed956639",
    "url": "/static/js/6.a7e65757.chunk.js"
  },
  {
    "revision": "98c2696e66aeea05656a",
    "url": "/static/js/60.827e2b24.chunk.js"
  },
  {
    "revision": "f604be185a055f1a90d1",
    "url": "/static/js/61.8c26123b.chunk.js"
  },
  {
    "revision": "09c5244873edbd1f4805",
    "url": "/static/js/62.c023a940.chunk.js"
  },
  {
    "revision": "d0ac7987ff36b4908a6e",
    "url": "/static/js/63.a3d8eacc.chunk.js"
  },
  {
    "revision": "d8e3308b73406444a053",
    "url": "/static/js/64.d065a5ae.chunk.js"
  },
  {
    "revision": "a3b888dcb8fd64f4d53b",
    "url": "/static/js/65.fdbacd51.chunk.js"
  },
  {
    "revision": "c2f43c9f9f32263db791",
    "url": "/static/js/66.f7493197.chunk.js"
  },
  {
    "revision": "70bd40da92989f6f024b",
    "url": "/static/js/67.b3cce332.chunk.js"
  },
  {
    "revision": "40dc0a9fbcb6a884b6c9",
    "url": "/static/js/68.fafbee82.chunk.js"
  },
  {
    "revision": "f096b4b6dd74f66a9e79",
    "url": "/static/js/69.bdc52995.chunk.js"
  },
  {
    "revision": "769e3418248ed2fe2741",
    "url": "/static/js/7.08021760.chunk.js"
  },
  {
    "revision": "f156bcff4a420f96eb12",
    "url": "/static/js/70.210d3e99.chunk.js"
  },
  {
    "revision": "4e2b513fee926f907ce2",
    "url": "/static/js/71.7a040aa1.chunk.js"
  },
  {
    "revision": "1860204a880a4210c07e",
    "url": "/static/js/72.bd974451.chunk.js"
  },
  {
    "revision": "6f6e9668686ae9c7b0ce",
    "url": "/static/js/73.e1f32d71.chunk.js"
  },
  {
    "revision": "8cd874ed043f4ef082ab",
    "url": "/static/js/74.fbdde12b.chunk.js"
  },
  {
    "revision": "f6518b335acbd6563bb5",
    "url": "/static/js/75.6fc20a58.chunk.js"
  },
  {
    "revision": "484ccafba414bb14131f",
    "url": "/static/js/76.f806a2a9.chunk.js"
  },
  {
    "revision": "61e3b99558a30c3374df",
    "url": "/static/js/77.c49a557e.chunk.js"
  },
  {
    "revision": "88e8ab614ff6b98944cc",
    "url": "/static/js/78.6997ca8b.chunk.js"
  },
  {
    "revision": "8bcc9081d156adbfa4cd",
    "url": "/static/js/79.edfb82cf.chunk.js"
  },
  {
    "revision": "02c795c3f97afbd59407",
    "url": "/static/js/8.9ae66901.chunk.js"
  },
  {
    "revision": "68019798d5a0390a04f0",
    "url": "/static/js/9.b2b71623.chunk.js"
  },
  {
    "revision": "9b8970a7863f89c948c3",
    "url": "/static/js/main.cf2c311d.chunk.js"
  },
  {
    "revision": "7494ade39e24d1c9bc8d",
    "url": "/static/js/runtime-main.b2a0d3f6.js"
  },
  {
    "revision": "35c254f1bc43c56e8cfae5d817be8d5f",
    "url": "/static/media/1.35c254f1.jpg"
  },
  {
    "revision": "e3ecc43c35f3e4d97bf187e8fccd9965",
    "url": "/static/media/2.e3ecc43c.jpg"
  },
  {
    "revision": "ed038830eaa255c8c2d58ed871d54f97",
    "url": "/static/media/3.ed038830.jpg"
  },
  {
    "revision": "98c972f61e9885a0ceeaa243aacfa7d6",
    "url": "/static/media/4.98c972f6.jpg"
  },
  {
    "revision": "3c60e090c7128eb1c57e03cabe091c05",
    "url": "/static/media/404.3c60e090.png"
  },
  {
    "revision": "11911410dca2de148f30954eb2fd5eab",
    "url": "/static/media/arrow_left.11911410.svg"
  },
  {
    "revision": "8ef6a08cdc1154920165680a4edde771",
    "url": "/static/media/arrow_right.8ef6a08c.svg"
  },
  {
    "revision": "035047178ed13101f120c47e1f36b043",
    "url": "/static/media/avatar.03504717.png"
  },
  {
    "revision": "ad04b412ac89dfa2f4fb8734d387cad0",
    "url": "/static/media/faq.ad04b412.jpg"
  },
  {
    "revision": "3d2fa2e544004aef2ea641698b715af6",
    "url": "/static/media/feather.3d2fa2e5.woff"
  },
  {
    "revision": "6a750f0119ba9c8ab8a994a4796599a6",
    "url": "/static/media/feather.6a750f01.ttf"
  },
  {
    "revision": "7975b0a027366be768319ee2f9e1734e",
    "url": "/static/media/feather.7975b0a0.svg"
  },
  {
    "revision": "931c9e74d0b20947054bfe6a5b74a838",
    "url": "/static/media/feather.931c9e74.eot"
  },
  {
    "revision": "b17d26ffb93bddee5e782ca657ae7efd",
    "url": "/static/media/kasino-logo.b17d26ff.png"
  },
  {
    "revision": "e45627865b1429eb3f10a2b6c19541bd",
    "url": "/static/media/parallax-4.e4562786.jpg"
  }
]);