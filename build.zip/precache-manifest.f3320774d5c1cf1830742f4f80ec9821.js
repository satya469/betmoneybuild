self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "1245fe8ee110f5a172da7128503568b8",
    "url": "/index.html"
  },
  {
    "revision": "7f2a5cc4fa8c7a9d4211",
    "url": "/static/css/0.3e68da18.chunk.css"
  },
  {
    "revision": "d0683984c3d118cee743",
    "url": "/static/css/13.2e947bf2.chunk.css"
  },
  {
    "revision": "94fcb705ea32d8bea518",
    "url": "/static/css/15.efdeeeb4.chunk.css"
  },
  {
    "revision": "6facd529f1e4e1c03e46",
    "url": "/static/css/16.834d426e.chunk.css"
  },
  {
    "revision": "684ce9486092d4bbcee3",
    "url": "/static/css/main.dfb41827.chunk.css"
  },
  {
    "revision": "7f2a5cc4fa8c7a9d4211",
    "url": "/static/js/0.3fdb0a75.chunk.js"
  },
  {
    "revision": "783f14fa45b10e088e68f98251448010",
    "url": "/static/js/0.3fdb0a75.chunk.js.LICENSE.txt"
  },
  {
    "revision": "61e6f19d7824a5126f09",
    "url": "/static/js/1.9d5ee2a3.chunk.js"
  },
  {
    "revision": "1e5bc3795b3e95a48845",
    "url": "/static/js/10.6a314f31.chunk.js"
  },
  {
    "revision": "d0683984c3d118cee743",
    "url": "/static/js/13.79cb18da.chunk.js"
  },
  {
    "revision": "f2fce78a0a0a19c2649c6b24e52364fd",
    "url": "/static/js/13.79cb18da.chunk.js.LICENSE.txt"
  },
  {
    "revision": "a156aa14fc8bb2931c23",
    "url": "/static/js/14.8c1e8356.chunk.js"
  },
  {
    "revision": "94fcb705ea32d8bea518",
    "url": "/static/js/15.8855a35a.chunk.js"
  },
  {
    "revision": "6facd529f1e4e1c03e46",
    "url": "/static/js/16.847f5982.chunk.js"
  },
  {
    "revision": "21a0aa5801d7187c1593",
    "url": "/static/js/17.34418a3f.chunk.js"
  },
  {
    "revision": "19937deaca928c008662",
    "url": "/static/js/18.74db7984.chunk.js"
  },
  {
    "revision": "d0e7c987a91f5b959fe4",
    "url": "/static/js/19.9f0c5bf7.chunk.js"
  },
  {
    "revision": "a305bebe571d9ae1f887",
    "url": "/static/js/2.14aaed2a.chunk.js"
  },
  {
    "revision": "f32ea78aab356205601f",
    "url": "/static/js/20.df061de8.chunk.js"
  },
  {
    "revision": "4d718919b96a3dded02d",
    "url": "/static/js/21.2061d664.chunk.js"
  },
  {
    "revision": "5a0a7a0b45412f69d9fb",
    "url": "/static/js/22.ec571b66.chunk.js"
  },
  {
    "revision": "f947db6dec2421923399",
    "url": "/static/js/23.c2543122.chunk.js"
  },
  {
    "revision": "ec241b18c6495e5302bd",
    "url": "/static/js/24.1ed4c29b.chunk.js"
  },
  {
    "revision": "d0aaa234c65b20f7bb01",
    "url": "/static/js/25.72de8321.chunk.js"
  },
  {
    "revision": "9d6f595e08c6bcc0d5bc",
    "url": "/static/js/26.35b83e49.chunk.js"
  },
  {
    "revision": "8929c5058ca5277863c5",
    "url": "/static/js/27.173378f3.chunk.js"
  },
  {
    "revision": "47302c7113785f994c3f",
    "url": "/static/js/28.151bd148.chunk.js"
  },
  {
    "revision": "22e078d53830745982bd",
    "url": "/static/js/29.92d12594.chunk.js"
  },
  {
    "revision": "5bc2a4d9deb516c06f69",
    "url": "/static/js/3.36a3ba3f.chunk.js"
  },
  {
    "revision": "7420087366b7c7db46ed",
    "url": "/static/js/30.f1afa0bc.chunk.js"
  },
  {
    "revision": "379d668e6fa68ef6e9b5",
    "url": "/static/js/31.022cd5b2.chunk.js"
  },
  {
    "revision": "617fb2d09e038f443161",
    "url": "/static/js/32.93290291.chunk.js"
  },
  {
    "revision": "7870e920c6c07f3ac289",
    "url": "/static/js/33.ad5b7d06.chunk.js"
  },
  {
    "revision": "8d65a43d6ca0c7030bdc",
    "url": "/static/js/34.a9376a17.chunk.js"
  },
  {
    "revision": "8574a6e12e6852b327f5",
    "url": "/static/js/35.4a8ed275.chunk.js"
  },
  {
    "revision": "1807dceda092861107d3",
    "url": "/static/js/36.01102703.chunk.js"
  },
  {
    "revision": "7d2fa027b07e0833a329",
    "url": "/static/js/37.42dcf478.chunk.js"
  },
  {
    "revision": "aa543fa858ae67a80b37",
    "url": "/static/js/38.4e016cf1.chunk.js"
  },
  {
    "revision": "5546dc8595d024937ca5",
    "url": "/static/js/39.91e07180.chunk.js"
  },
  {
    "revision": "f236fcd18ae2c209a162",
    "url": "/static/js/4.e6f53979.chunk.js"
  },
  {
    "revision": "b5ac5ace88360e8a6ff9",
    "url": "/static/js/40.0550e813.chunk.js"
  },
  {
    "revision": "0597f19be809c0f82806",
    "url": "/static/js/41.37cbca77.chunk.js"
  },
  {
    "revision": "1a0aeb9d2c53672ed9be",
    "url": "/static/js/42.d45d3169.chunk.js"
  },
  {
    "revision": "7b4e168047cac6a392b2",
    "url": "/static/js/43.5bb10872.chunk.js"
  },
  {
    "revision": "9e40c7e7a11975053c03",
    "url": "/static/js/44.0b62c60b.chunk.js"
  },
  {
    "revision": "466ea54bb849b59be0c8",
    "url": "/static/js/45.bce9b96a.chunk.js"
  },
  {
    "revision": "d4d4ebf9308835a75b78",
    "url": "/static/js/46.486b2014.chunk.js"
  },
  {
    "revision": "2277d6f39e20056abfba",
    "url": "/static/js/47.bbdedcbd.chunk.js"
  },
  {
    "revision": "3d245222071791855683",
    "url": "/static/js/48.274cd5aa.chunk.js"
  },
  {
    "revision": "c950e23e7a6899cf5295",
    "url": "/static/js/49.49980822.chunk.js"
  },
  {
    "revision": "36c16800ac6e4a7cc1cd",
    "url": "/static/js/5.e3215d71.chunk.js"
  },
  {
    "revision": "afdc6597cffaae50601f",
    "url": "/static/js/50.10e4f5bc.chunk.js"
  },
  {
    "revision": "70c021ee65b28112f50d",
    "url": "/static/js/51.12ee8129.chunk.js"
  },
  {
    "revision": "6b198bb524ef69382bb8",
    "url": "/static/js/52.c5637b4c.chunk.js"
  },
  {
    "revision": "82ee7f2360476d8717ac",
    "url": "/static/js/53.979f5573.chunk.js"
  },
  {
    "revision": "731f68fcebdaed9594b0",
    "url": "/static/js/54.8886d5bc.chunk.js"
  },
  {
    "revision": "a5bbd00560a6d6c950f7",
    "url": "/static/js/55.60e3355c.chunk.js"
  },
  {
    "revision": "c5d916dddb2561ce5291",
    "url": "/static/js/56.99eda719.chunk.js"
  },
  {
    "revision": "e7623ea17cfe9c6d82ca",
    "url": "/static/js/57.44d78dbf.chunk.js"
  },
  {
    "revision": "4a043357a3d45b622ec0",
    "url": "/static/js/58.e49ca425.chunk.js"
  },
  {
    "revision": "2050ffa5a15d3bd8f412",
    "url": "/static/js/59.9eddbfdd.chunk.js"
  },
  {
    "revision": "9d932ca6026cf03a358d",
    "url": "/static/js/6.2fbe9417.chunk.js"
  },
  {
    "revision": "ff5c980fdee27c0ad32e",
    "url": "/static/js/60.4cf319ce.chunk.js"
  },
  {
    "revision": "f965624317cd4b07e0d7",
    "url": "/static/js/61.d744cb62.chunk.js"
  },
  {
    "revision": "f8108df1e19979447cd6",
    "url": "/static/js/62.b3f3b197.chunk.js"
  },
  {
    "revision": "90d0e5c2adb838605ee9",
    "url": "/static/js/63.85cdd885.chunk.js"
  },
  {
    "revision": "18f63bcb427007e21d44",
    "url": "/static/js/64.74c20697.chunk.js"
  },
  {
    "revision": "733852a5d32d0d5f37a1",
    "url": "/static/js/65.1a20a16b.chunk.js"
  },
  {
    "revision": "6a3c4f30afb09382aca8",
    "url": "/static/js/66.87414e7a.chunk.js"
  },
  {
    "revision": "c62f35ac28e8cc06f75c",
    "url": "/static/js/67.fbf59243.chunk.js"
  },
  {
    "revision": "86c6d1f2ddd25b136cbb",
    "url": "/static/js/68.7b3d6cc0.chunk.js"
  },
  {
    "revision": "d4b26a09e4baf1b56c79",
    "url": "/static/js/69.ad65ded4.chunk.js"
  },
  {
    "revision": "12c196dc6aa5bf31584e",
    "url": "/static/js/7.617fdd95.chunk.js"
  },
  {
    "revision": "76188818f507af01b19c",
    "url": "/static/js/70.f98658d3.chunk.js"
  },
  {
    "revision": "92e62d75d4ed253947fc",
    "url": "/static/js/71.abe6f24f.chunk.js"
  },
  {
    "revision": "8ec26db6a9c14ac88ecf",
    "url": "/static/js/72.fda38111.chunk.js"
  },
  {
    "revision": "425965c923e4cc7e7b6c",
    "url": "/static/js/73.803ee3df.chunk.js"
  },
  {
    "revision": "b74bcfda062c161aa368",
    "url": "/static/js/74.c5b0b96e.chunk.js"
  },
  {
    "revision": "ba4ee77e2feb78fd57c9",
    "url": "/static/js/75.59456a42.chunk.js"
  },
  {
    "revision": "3ce703b8e8bdffd5a7b4",
    "url": "/static/js/76.b457e937.chunk.js"
  },
  {
    "revision": "148e18589fe65667f733",
    "url": "/static/js/77.126fd888.chunk.js"
  },
  {
    "revision": "acb6a5ba6c89d8248467",
    "url": "/static/js/78.52772a6c.chunk.js"
  },
  {
    "revision": "ef216c2d3bb51b22dab9",
    "url": "/static/js/79.70856be8.chunk.js"
  },
  {
    "revision": "6bf78ab8dbc3ef76d3b1",
    "url": "/static/js/8.8417bd4d.chunk.js"
  },
  {
    "revision": "5be7d8e44c3135376c71",
    "url": "/static/js/80.cc8afecb.chunk.js"
  },
  {
    "revision": "4ea14f0673db4a77a1f7",
    "url": "/static/js/9.59df0e95.chunk.js"
  },
  {
    "revision": "684ce9486092d4bbcee3",
    "url": "/static/js/main.93afe1d7.chunk.js"
  },
  {
    "revision": "2725d59fea9f597e9689",
    "url": "/static/js/runtime-main.1be1db66.js"
  },
  {
    "revision": "35c254f1bc43c56e8cfae5d817be8d5f",
    "url": "/static/media/1.35c254f1.jpg"
  },
  {
    "revision": "e3ecc43c35f3e4d97bf187e8fccd9965",
    "url": "/static/media/2.e3ecc43c.jpg"
  },
  {
    "revision": "ed038830eaa255c8c2d58ed871d54f97",
    "url": "/static/media/3.ed038830.jpg"
  },
  {
    "revision": "98c972f61e9885a0ceeaa243aacfa7d6",
    "url": "/static/media/4.98c972f6.jpg"
  },
  {
    "revision": "3c60e090c7128eb1c57e03cabe091c05",
    "url": "/static/media/404.3c60e090.png"
  },
  {
    "revision": "11911410dca2de148f30954eb2fd5eab",
    "url": "/static/media/arrow_left.11911410.svg"
  },
  {
    "revision": "8ef6a08cdc1154920165680a4edde771",
    "url": "/static/media/arrow_right.8ef6a08c.svg"
  },
  {
    "revision": "035047178ed13101f120c47e1f36b043",
    "url": "/static/media/avatar.03504717.png"
  },
  {
    "revision": "ad04b412ac89dfa2f4fb8734d387cad0",
    "url": "/static/media/faq.ad04b412.jpg"
  },
  {
    "revision": "3d2fa2e544004aef2ea641698b715af6",
    "url": "/static/media/feather.3d2fa2e5.woff"
  },
  {
    "revision": "6a750f0119ba9c8ab8a994a4796599a6",
    "url": "/static/media/feather.6a750f01.ttf"
  },
  {
    "revision": "7975b0a027366be768319ee2f9e1734e",
    "url": "/static/media/feather.7975b0a0.svg"
  },
  {
    "revision": "931c9e74d0b20947054bfe6a5b74a838",
    "url": "/static/media/feather.931c9e74.eot"
  },
  {
    "revision": "b17d26ffb93bddee5e782ca657ae7efd",
    "url": "/static/media/kasino-logo.b17d26ff.png"
  },
  {
    "revision": "e45627865b1429eb3f10a2b6c19541bd",
    "url": "/static/media/parallax-4.e4562786.jpg"
  }
]);